let userName = prompt("enter you name");
if (userName) {
  alert("welcome" +' '+ userName);
} else {
  alert("enter your name");
}
